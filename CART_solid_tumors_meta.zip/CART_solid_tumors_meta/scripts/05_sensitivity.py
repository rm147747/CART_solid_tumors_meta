#!/usr/bin/env python3
"""Sensitivity analyses: Freeman-Tukey transformation + DerSimonian-Laird."""
import json, numpy as np
from scipy import stats, optimize
from scripts_02_meta_analysis import STUDIES, inv_logit
import pandas as pd

df = pd.DataFrame(STUDIES)
p = df['events'] / df['n'].values
n = df['n'].values

# Freeman-Tukey double arcsine
ft = 0.5 * (np.arcsin(np.sqrt(p * n / (n + 1))) + 
            np.arcsin(np.sqrt((p * n + 1) / (n + 1))))
v_ft = 1.0 / (4.0 * (n + 1.0))

# DerSimonian-Laird
w = 1.0 / v_ft
y_fe = np.sum(w * ft) / np.sum(w)
Q = np.sum(w * (ft - y_fe)**2)
tau2 = max(0.0, (Q - (len(df) - 1)) / (np.sum(w) - np.sum(w**2)/np.sum(w)))
w_re = 1.0 / (v_ft + tau2)
y_re = np.sum(w_re * ft) / np.sum(w_re)

# HKSJ
sw = np.sum(w_re)
var_hksj = np.sum(w_re**2 * (ft - y_re)**2 / sw**2) * (len(df) / (len(df) - 1))
t = stats.t.ppf(0.975, len(df) - 1)
ci_l = y_re - t * np.sqrt(var_hksj)
ci_u = y_re + t * np.sqrt(var_hksj)

# Back-transform (approximate harmonic mean)
n_hm = len(n) / np.sum(1.0 / n)
p_approx = np.sin(y_re)**2  # approximate
# Better: use exact back-transform
# p = 0.5 * (1 - sign(cos(y)) * sqrt(1 - (sin(y) + (sin(y)-1/sin(y))/n)^2))

with open('../data/processed/results.json') as f:
    results = json.load(f)

results['sensitivity_ft_dl'] = {
    'method': 'Freeman-Tukey + DerSimonian-Laird + HKSJ',
    'ORR_pct_approx': round(p_approx * 100, 1),
    'CI_95_approx': [round(np.sin(ci_l)**2 * 100, 1), round(np.sin(ci_u)**2 * 100, 1)],
    'tau2': round(tau2, 2),
    'note': 'Approximate back-transform; exact requires harmonic mean sample size'
}

# Leave-one-out
loo_results = []
for i in range(len(df)):
    mask = np.ones(len(df), dtype=bool)
    mask[i] = False
    y_loo, v_loo = logit_transform(df.loc[mask, 'events'].values, df.loc[mask, 'n'].values)
    r_loo = meta_reml_hksj(y_loo, v_loo)
    loo_results.append({
        'excluded': df.loc[i, 'author'],
        'ORR_pct': round(inv_logit(r_loo['beta']) * 100, 1),
        'CI_95': [round(inv_logit(r_loo['ci_lower']) * 100, 1),
                   round(inv_logit(r_loo['ci_upper']) * 100, 1)],
        'I2': round(r_loo['I2'], 1)
    })

results['leave_one_out'] = loo_results

with open('../data/processed/results.json', 'w') as f:
    json.dump(results, f, indent=2)

print("Sensitivity analyses complete.")
