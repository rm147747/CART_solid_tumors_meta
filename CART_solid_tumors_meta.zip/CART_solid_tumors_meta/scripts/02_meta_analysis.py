#!/usr/bin/env python3
"""
CAR-T Solid Tumors Meta-Analysis: Primary Analysis
Methods: Logit transformation + REML estimation + HKSJ adjustment

Moreira RB et al. npj Precision Oncology (submitted)
PROSPERO: CRD420261294180
"""

import sys
import json
import numpy as np
import pandas as pd
from scipy import stats, optimize

sys.path.insert(0, '..')

# ============================================================================
# EXTRACTED DATA: 13 single-arm CAR-T trials in solid tumors
# ============================================================================
STUDIES = [
    {"author": "Beatty GL",    "target": "MSLN",      "tumor": "Pancreatic",     "year": 2014, "n": 6,  "events": 0,  "armored": False},
    {"author": "Ahmed N",      "target": "HER2",      "tumor": "Sarcoma",        "year": 2015, "n": 10, "events": 0,  "armored": False},
    {"author": "Junghans",     "target": "PSMA",      "tumor": "Prostate",       "year": 2016, "n": 7,  "events": 2,  "armored": False},
    {"author": "Katz SC",      "target": "CEA",       "tumor": "Colorectal",     "year": 2015, "n": 10, "events": 0,  "armored": False},
    {"author": "Hege",         "target": "TAG-72",    "tumor": "Colorectal",     "year": 2017, "n": 16, "events": 0,  "armored": False},
    {"author": "Adusumilli",   "target": "MSLN",      "tumor": "Mesothelioma",   "year": 2021, "n": 21, "events": 0,  "armored": False},
    {"author": "Haas",         "target": "MSLN",      "tumor": "Solid tumors",   "year": 2019, "n": 15, "events": 0,  "armored": False},
    {"author": "Shi",          "target": "GPC3",      "tumor": "HCC",            "year": 2020, "n": 13, "events": 1,  "armored": False},
    {"author": "Heczey",       "target": "GPC3",      "tumor": "HCC",            "year": 2024, "n": 30, "events": 12, "armored": True},
    {"author": "Chen N",       "target": "GCC+CD19",  "tumor": "Colorectal",     "year": 2024, "n": 15, "events": 6,  "armored": True},
    {"author": "Narayan",      "target": "PSMA",      "tumor": "Prostate",       "year": 2022, "n": 11, "events": 3,  "armored": True},
    {"author": "Wang",         "target": "MSLN",      "tumor": "Solid tumors",   "year": 2021, "n": 10, "events": 0,  "armored": True},
    {"author": "Qi",           "target": "CLDN18.2",  "tumor": "Gastric/GEJ",    "year": 2022, "n": 37, "events": 18, "armored": False},
]


def logit_transform(events, n, cc=0.5):
    """Logit transformation with continuity correction for zero/n cells."""
    e_adj = np.where(events == 0, cc, np.where(events == n, n - cc, events))
    p = e_adj / n
    y = np.log(p / (1 - p))
    v = 1.0 / e_adj + 1.0 / (n - e_adj)
    return y, v


def inv_logit(x):
    """Inverse logit transformation."""
    return np.exp(x) / (1.0 + np.exp(x))


def meta_reml_hksj(y, v, conf_level=0.95):
    """
    Random-effects meta-analysis: REML tau2 + HKSJ confidence intervals.
    
    Parameters
    ----------
    y : array — effect sizes (transformed)
    v : array — within-study variances  
    conf_level : float — confidence level (default 0.95)
    
    Returns
    -------
    dict — beta, tau2, se, ci_lower, ci_upper, pi_lower, pi_upper, I2, Q
    """
    k = len(y)
    
    # Fixed-effect
    w_fe = 1.0 / v
    y_fe = np.sum(w_fe * y) / np.sum(w_fe)
    Q = np.sum(w_fe * (y - y_fe)**2)
    
    # REML tau2 via profile likelihood
    def neg_reml(tau2):
        if tau2 < 0:
            return 1e10
        w = 1.0 / (v + tau2)
        S = np.sum(w)
        yb = np.sum(w * y) / S
        return 0.5 * (np.sum(np.log(v + tau2)) + 
                      np.sum((y - yb)**2 / (v + tau2)) + np.log(S))
    
    opt = optimize.minimize_scalar(
        neg_reml, bounds=(0.0, 50.0), method='bounded', options={'xatol': 1e-12})
    tau2 = opt.x
    
    # Random-effects weights
    w = 1.0 / (v + tau2)
    sw = np.sum(w)
    beta = np.sum(w * y) / sw
    
    # HKSJ variance
    var_hksj = np.sum(w**2 * (y - beta)**2 / sw**2) * (k / (k - 1))
    se = np.sqrt(var_hksj)
    
    # t-distribution
    t = stats.t.ppf(1.0 - (1.0 - conf_level) / 2.0, k - 1)
    
    ci_l = beta - t * se
    ci_u = beta + t * se
    pi_l = beta - t * np.sqrt(var_hksj + tau2)
    pi_u = beta + t * np.sqrt(var_hksj + tau2)
    
    I2 = max(0.0, (Q - (k - 1)) / Q * 100.0) if Q > 0 else 0.0
    
    return {
        'beta': beta, 'tau2': tau2, 'se': se,
        'ci_lower': ci_l, 'ci_upper': ci_u,
        'pi_lower': pi_l, 'pi_upper': pi_u,
        'I2': I2, 'Q': Q
    }


def main():
    df = pd.DataFrame(STUDIES)
    df.to_csv('../data/extracted_data.csv', index=False)
    
    # Primary analysis
    y, v = logit_transform(df['events'].values, df['n'].values)
    r = meta_reml_hksj(y, v)
    
    results = {
        'primary': {
            'method': 'Logit + REML + HKSJ',
            'k': 13, 'N': 201, 'events': 42,
            'ORR_pct': round(inv_logit(r['beta']) * 100, 1),
            'CI_95': [round(inv_logit(r['ci_lower']) * 100, 1), 
                      round(inv_logit(r['ci_upper']) * 100, 1)],
            'PI_95': [round(inv_logit(r['pi_lower']) * 100, 1),
                      round(inv_logit(r['pi_upper']) * 100, 1)],
            'tau2': round(r['tau2'], 2),
            'I2': round(r['I2'], 1),
            'Q': round(r['Q'], 2)
        }
    }
    
    with open('../data/processed/results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("Primary analysis complete. Results saved to data/processed/results.json")
    print("ORR: %.1f%% (%.1f-%.1f%%)" % (
        results['primary']['ORR_pct'],
        results['primary']['CI_95'][0],
        results['primary']['CI_95'][1]))


if __name__ == '__main__':
    main()
