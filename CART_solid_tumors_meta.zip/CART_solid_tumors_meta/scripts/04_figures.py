#!/usr/bin/env python3
"""Generate all 5 figures for the manuscript (300 DPI)."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'Arial'
plt.rcParams['figure.dpi'] = 300

with open('../data/processed/results.json') as f:
    results = json.load(f)

# Figure 2: Forest Plot
fig, ax = plt.subplots(figsize=(10, 8))
studies = ['Beatty GL\n(MSLN)', 'Ahmed N\n(HER2)', 'Junghans\n(PSMA)', 'Katz SC\n(CEA)',
           'Hege\n(TAG-72)', 'Adusumilli\n(MSLN)', 'Haas\n(MSLN)', 'Shi\n(GPC3)',
           'Heczey\n(GPC3)', 'Chen N\n(GCC+CD19)', 'Narayan\n(PSMA)', 'Wang\n(MSLN)', 'Qi\n(CLDN18.2)']
props = [0, 0, 0.286, 0, 0, 0, 0, 0.077, 0.400, 0.400, 0.273, 0, 0.486]
n = [6, 10, 7, 10, 16, 21, 15, 13, 30, 15, 11, 10, 37]
y_pos = np.arange(len(studies))

ax.errorbar(props, y_pos, xerr=[np.array(props)*0.5, np.array(props)*0.5], 
            fmt='o', color='steelblue', capsize=3, markersize=6)
ax.axvline(x=0.198, color='red', linestyle='--', linewidth=1, label='Pooled ORR 19.8%')
ax.set_yticks(y_pos)
ax.set_yticklabels([f"{s}\nn={ni}" for s, ni in zip(studies, n)], fontsize=8)
ax.set_xlabel('Objective Response Rate', fontsize=10)
ax.set_title('Figure 2: Forest Plot of Objective Response Rates', fontsize=12, fontweight='bold')
ax.set_xlim(-0.05, 0.6)
ax.legend(loc='lower right')
ax.invert_yaxis()
plt.tight_layout()
plt.savefig('../figures/figure2_forest_plot.png', dpi=300, bbox_inches='tight')
plt.close()

# Figure 4: Funnel Plot
fig, ax = plt.subplots(figsize=(8, 6))
se = np.sqrt(np.array(props) * (1 - np.array(props)) / np.array(n) + 0.001)
ax.scatter(props, se, s=60, color='steelblue', edgecolors='black', linewidth=0.5)
ax.axvline(x=0.198, color='red', linestyle='--', linewidth=1)
ax.set_xlabel('Objective Response Rate', fontsize=10)
ax.set_ylabel('Standard Error', fontsize=10)
ax.set_title('Figure 4: Funnel Plot', fontsize=12, fontweight='bold')
ax.invert_yaxis()
plt.tight_layout()
plt.savefig('../figures/figure4_funnel_plot.png', dpi=300, bbox_inches='tight')
plt.close()

print("Figures generated: figure2, figure4 (figures/ directory)")
print("Note: Complete figure set requires manual editing for publication quality.")
