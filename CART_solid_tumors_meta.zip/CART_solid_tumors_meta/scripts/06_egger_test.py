#!/usr/bin/env python3
"""Publication bias: Egger's linear regression test on funnel plot."""
import json, numpy as np
from scipy import stats
from scripts_02_meta_analysis import STUDIES, logit_transform
import pandas as pd

df = pd.DataFrame(STUDIES)
y, v = logit_transform(df['events'].values, df['n'].values)
se = np.sqrt(v)

# Egger's test: regression of standardized effect on precision
precision = 1.0 / se
std_effect = y / se

slope, intercept, r_value, p_value, std_err = stats.linregress(precision, std_effect)

with open('../data/processed/results.json') as f:
    results = json.load(f)

results['egger_test'] = {
    'intercept': round(intercept, 4),
    'slope': round(slope, 4),
    'p_value': round(p_value, 4),
    'significant_at_0.05': p_value < 0.05,
    'interpretation': 'Asymmetry suggests potential small-study effects' if p_value < 0.05 else 'No significant asymmetry'
}

with open('../data/processed/results.json', 'w') as f:
    json.dump(results, f, indent=2)

print("Egger test: intercept=%.4f, p=%.4f %s" % (
    intercept, p_value, '(significant)' if p_value < 0.05 else ''))
