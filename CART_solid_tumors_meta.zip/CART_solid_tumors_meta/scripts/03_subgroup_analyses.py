#!/usr/bin/env python3
"""Subgroup analyses: target-specific and armored vs non-armored."""
import json, numpy as np, pandas as pd
from scipy import stats
from scripts_02_meta_analysis import logit_transform, inv_logit, meta_reml_hksj

df = pd.read_csv('../data/extracted_data.csv')

with open('../data/processed/results.json') as f:
    results = json.load(f)

# Armored vs non-armored
for label, mask in [('armored', df.armored), ('non_armored', ~df.armored)]:
    sub = df[mask]
    y, v = logit_transform(sub['events'].values, sub['n'].values)
    r = meta_reml_hksj(y, v)
    results[label] = {
        'k': int(mask.sum()), 'N': int(sub['n'].sum()),
        'ORR_pct': round(inv_logit(r['beta'])*100, 1),
        'CI_95': [round(inv_logit(r['ci_lower'])*100, 1), round(inv_logit(r['ci_upper'])*100, 1)]
    }

# Target-specific (exact binomial for k=1, pooled for k>1)
for target, group in df.groupby('target'):
    tn = int(group['n'].sum())
    te = int(group['events'].sum())
    ci = stats.binomtest(te, tn).proportion_ci()
    results[f'target_{target}'] = {
        'k': len(group), 'N': tn, 'events': te,
        'ORR_pct': round(te/tn*100, 1),
        'CI_95': [round(ci.low*100, 1), round(ci.high*100, 1)]
    }

with open('../data/processed/results.json', 'w') as f:
    json.dump(results, f, indent=2)

print("Subgroup analyses complete.")
