# CAR-T Cell Therapy in Solid Tumors: Evidence Mapping and Meta-Analysis

**Authors:** Raphael Brandao Moreira, MD; Indianara Valgas Brandao, MD; Erika Simplicio, MD; Nilo Jorge Leao, MD, PhD; Andre Miotto, MD

**Corresponding Author:** Raphael Brandao Moreira, MD  
Division of Hematology/Oncology, Department of Medicine  
UF Health Jacksonville, University of Florida  
655 West 8th Street, Jacksonville, FL 32209, USA  
Email: raphael.moreira@jax.ufl.edu

**Registration:** PROSPERO 2026 CRD420261294180

---

## Key Results

| Analysis | ORR | 95% CI | k | N | I2 |
|----------|-----|--------|---|---|-----|
| Overall (primary) | 19.8% | 10.4-34.4% | 13 | 201 | 52.9% |
| Sensitivity (FT+DL) | 14.4% | 5.4-26.7% | 13 | 201 | 79.2% |
| CLDN18.2 (Gastric) | 48.6% | 31.9-65.6% | 1 | 37 | - |
| GPC3 (HCC) | 27.9% | 15.3-43.0% | 2 | 43 | - |
| PSMA (Prostate) | 27.8% | 8.5-57.8% | 2 | 18 | - |
| MSLN (Pancreas/Meso) | 0% | 0-11.6% | 2 | 30 | - |
| HER2 (Sarcoma) | 0% | 0-17.6% | 1 | 19 | - |
| Armored | 26.0% | 11.1-48.8% | 4 | 73 | - |
| Non-Armored | 18.0% | 6.4-41.3% | 9 | 128 | - |

**CT041-ST-01 (RCT validation):** PFS HR 0.37 (95% CI: 0.24-0.56)

---

## Repository Structure

```
CART_solid_tumors_meta/
|-- scripts/
|   |-- 02_meta_analysis.py          # Main analysis (REML + HKSJ)
|   |-- 03_subgroup_analyses.py      # Target-specific and armored analyses
|   |-- 04_figures.py                # Generate all 5 figures
|   |-- 05_sensitivity.py            # Sensitivity analyses
|   |-- 06_egger_test.py             # Publication bias assessment
|-- data/
|   |-- extracted_data.csv           # Extracted study data (13 studies)
|   |-- processed/
|       |-- results.json             # All analysis results
|-- tables/
|   |-- table1_study_characteristics.csv
|   |-- table2_target_specific_orr.csv
|   |-- table3_ongoing_trials.csv
|-- figures/                         # Generated figures (300 DPI)
|-- manuscript/
|   |-- manuscript.docx              # Submitted manuscript
|-- supplementary/
|   |-- prisma_search_strategy.md    # Database search strings
|   |-- jbi_assessment.csv           # Risk of bias assessment
|   |-- sensitivity_results.csv      # Leave-one-out analysis
|-- README.md
|-- requirements.txt
```

---

## Reproducibility

### Installation

```bash
pip install -r requirements.txt
```

### Run Full Analysis

```bash
python scripts/02_meta_analysis.py
python scripts/03_subgroup_analyses.py
python scripts/05_sensitivity.py
python scripts/06_egger_test.py
python scripts/04_figures.py
```

All results will be saved to `data/processed/` and `figures/`.

---

## Methods Summary

- **Design:** Evidence mapping with integrated meta-analysis of proportions
- **Transformation:** Logit
- **Tau2 estimation:** REML (Restricted Maximum Likelihood)
- **Confidence intervals:** HKSJ (Hartung-Knapp-Sidik-Jonkman) adjustment
- **Prediction intervals:** Reported for all syntheses
- **Heterogeneity:** I-squared, Cochran's Q, tau-squared
- **Publication bias:** Funnel plot, Egger's test
- **Certainty:** GRADE framework

---

## License

MIT License
